const menu = (prefix, NomeDoBot) => {
  
// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
return `​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
╭───────────────
╎
┝〢 ${NomeDoBot} 
╎
╰──────────
╎
╎⩺ Bem vindo ao Menu
╎⩺ Multi-Device SKYNERD  
╎
╎⩺ BOT EM DESENVOLVIMENTO. 
╎⩺ Fique cientes disso. 
╰──────────╮
╭──────────╯
┝━〢⎙ MENU/DE/CMDS
╎
╎𖢼⩺ ${prefix}hospedar (INFO DO BOT ANTIGO)
╎𖢼⩺ ${prefix}Menudono
╎𖢼⩺ ${prefix}Efeitosimg
╎𖢼⩺ ${prefix}Menuadm
╎𖢼⩺ ${prefix}Menupremium
╎𖢼⩺ ${prefix}Alteradores
╰──────────╮
╭──────────╯
┝━〢⎙ PARA/MEMBROS
╎
╎𖢼⩺ ${prefix}Infobot
╎𖢼⩺ ${prefix}Idiomas 
╎𖢼⩺ ${prefix}Bug (QUESTIONE) 
╎𖢼⩺ ${prefix}Sugestao (DICA) 
╎𖢼⩺ ${prefix}Avalie (O-QUAO-BOM) 
╰──────────╮
╭──────────╯
┝━〢⎙ INFO/DONO
╎
╎𖢼⩺ ${prefix}Fotomenu (MARCAR-IMG) 
╎𖢼⩺ ${prefix}audio-menu
╎𖢼⩺ ${prefix}InfoBemvindo
╎𖢼⩺ ${prefix}Infopalavrão
╎𖢼⩺ ${prefix}Infolistanegra
╎𖢼⩺ ${prefix}Infobancarac
╎𖢼⩺ ${prefix}Infovotação
╎𖢼⩺ ${prefix}Infocontador
╎𖢼⩺ ${prefix}Infosorteio
╰──────────╮
╭──────────╯
┝━〢⎙ PESQUISA/BAIXAR
╎
╎𖢼⩺ ${prefix}Play (NOME) 
╎𖢼⩺ ${prefix}Playmp4 (NOME) 
╎𖢼⩺ ${prefix}Ytsearch (NOME) 
╎𖢼⩺ ${prefix}Ytmp4 (LINK) 
╎𖢼⩺ ${prefix}Ytmp3 (LINK) 
╎𖢼⩺ ${prefix}Tiktok (LINK) 
╎𖢼⩺ ${prefix}Instagram (LINK) 
╎𖢼⩺ ${prefix}Insta-story (NOME) 
╎𖢼⩺ ${prefix}Facebook (LINK) 
╎𖢼⩺ ${prefix}Twitter (LINK) 
╎𖢼⩺ ${prefix}Imgpralink (MARCAR)
╎𖢼⩺ ${prefix}Videopralink (MARCAR-V) 
╰──────────╮
╭──────────╯
┝━〢⎙ INFORMAÇÕES
╎
╎𖢼⩺ ${prefix}Ping (VELO) 
╎𖢼⩺ ${prefix}Gitdobot
╎𖢼⩺ ${prefix}Atividade
╎𖢼⩺ ${prefix}Rankativo
╎𖢼⩺ ${prefix}Checkativo (@MARCAR)
╎𖢼⩺ ${prefix}Ranklevel (DE-TODOS) 
╰──────────╮
╭──────────╯
┝━〢⎙ FIGURINHAS
╎
╎𖢼⩺ ${prefix}Attp (TEXTO)
╎𖢼⩺ ${prefix}Ttp (TEXTO)
╎𖢼⩺ ${prefix}Fsticker (MARCAR-FOTO)
╎𖢼⩺ ${prefix}Sticker (MARCAR-FOTO)
╎𖢼⩺ ${prefix}Toimg (MARCAR-FIGU)
╎𖢼⩺ ${prefix}Togif (MARCAR-FIGU)
╎𖢼⩺ ${prefix}Roubar (TEXT/TEXT)
╰──────────╮
╭──────────╯
┝━〢⎙ CMDS/BÁSICOS
╎
╎𖢼⩺ ${prefix}Gtts (LINGUAGEM + TEXTO)
╎𖢼⩺ ${prefix}Traduzir Hello 
╎𖢼⩺ ${prefix}Tagme 
╎𖢼⩺ ${prefix}Emoji
╎𖢼⩺ ${prefix}Emojimix
╎𖢼⩺ ${prefix}Tabela (LETRAS) 
╎𖢼⩺ ${prefix}Simi (FALE-ALGO)  
╎𖢼⩺ ${prefix}Frases
╎𖢼⩺ ${prefix}Calcular (1 + 1)
╎𖢼⩺ ${prefix}Fazernick (NICK)
╎𖢼⩺ ${prefix}Bot
╰─────────────╯

`
}

exports.menu = menu

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.
