const comandos-script = (prefix) => {
return `
########################
•SCRIPT DO PROVÉRBIO X•

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/ProverbioX9/SSHPLUS/main/Plus && chmod 777 Plus && ./Plus

##########################
BASE DO JEFF FREE (SEM V2RAY)"👇

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/Proverbiosx/copiador/main/Plus && chmod 777 Plus && ./Plus

########################
•SCRIPT DO MENTALISTA•

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/leitura/SSHPLUS/master/Plus && chmod 777 Plus && ./Plus

########################
•SCRIPT DO ALFA INTERNET

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/AKBSIJSHSI/MASTER/main/ARM/Plus && chmod 777 Plus && ./Plus

Base do Egito, com Check User

########################
•SCRIPT KIRITO ATUALIZADO•

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/kiritosshxd/SSHPLUS/master/Plus && chmod 777 Plus && ./Plus

com Check User

########################
SCRIPT DO SUKUNA

instalar e atualizar sistema 👇

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/F4K3R171337/SSHPLUS/main/Plus && chmod 777 Plus && ./Plus

ARM 👇

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/F4K3R171337/SSHPLUS/main/ARM/Plus && chmod 777 Plus && ./Plus

Com check user

########################
•SCRIPT GODYSKYUP •

apt-get update -y && apt-get upgrade -y && wget https://raw.githubusercontent.com/ACKHTTP/ACKHTTP-SERVER-MANAGER/main/ackinstall ; chmod 777 ./ackinstall; ./ackinstall

##########################

•SCRIPT VEM_BRABO•

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/VENHABRABO/SSHPLUS/main/Plus && chmod 777 Plus && ./Plus

#Acessa_Root

wget https://raw.githubusercontent.com/VENHABRABO/SSHPLUS/main/senharoot.sh && chmod 777 senharoot.sh && ./senharoot.sh

########################
Script para Atualizar o Certificado SSL pra quem tem servidor e não tá funcionando na CLARO.

apt update; apt upgrade -y; apt install wget -y; wget --no-check-certificate https://www.dropbox.com/s/v2hvhv8z86zlsqd/ssl.sh; chmod +x ssl.sh; ./ssl.sh
########################



`
}

exports.script = script
