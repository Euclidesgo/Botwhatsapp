#!bin/bash
GREEN='\033[0;32m'
while : 
do
echo "${GREEN} SKYNERD - Auto reconexão ativada para prevenção de quedas.."
    node index.js
    sleep 1

done
